package app.codepad.notepad

import android.os.SystemClock
import android.text.Editable
import android.text.TextWatcher

/**
 * История правок. Набор подряд (в том числе слова, которые клавиатура Samsung
 * перезаписывает по букве) склеивается в один шаг отмены.
 */
class UndoManager {
    private class Edit(var start: Int, var before: String, var after: String, var time: Long)

    private val undoStack = ArrayDeque<Edit>()
    private val redoStack = ArrayDeque<Edit>()
    private var pending = ""
    private var breakMerge = false

    var enabled = true
    var onChange: (() -> Unit)? = null

    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()

    val watcher = object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            if (enabled && s != null) pending = s.subSequence(start, start + count).toString()
        }

        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            if (enabled && s != null) record(start, pending, s.subSequence(start, start + count).toString())
        }

        override fun afterTextChanged(s: Editable?) {}
    }

    private fun record(start: Int, before: String, after: String) {
        if (before == after) return
        val now = SystemClock.uptimeMillis()
        redoStack.clear()
        val last = undoStack.lastOrNull()
        // новое слово после пробела — отдельный шаг отмены
        val newWord = before.isEmpty() && after.isNotBlank() && last != null && last.after.endsWith(' ')
        if (last != null && !breakMerge && !newWord && now - last.time < MERGE_MS && after.indexOf('\n') < 0) {
            val lastEnd = last.start + last.after.length
            // продолжение набора или правка только что набранного хвоста
            if (start >= last.start && start + before.length == lastEnd && last.after.endsWith(before)) {
                last.after = last.after.substring(0, last.after.length - before.length) + after
                last.time = now
                onChange?.invoke()
                return
            }
            // Backspace подряд
            if (after.isEmpty() && last.after.isEmpty() && start + before.length == last.start) {
                last.start = start
                last.before = before + last.before
                last.time = now
                onChange?.invoke()
                return
            }
        }
        breakMerge = false
        undoStack.addLast(Edit(start, before, after, now))
        if (undoStack.size > MAX_STEPS) undoStack.removeFirst()
        onChange?.invoke()
    }

    /** Возвращает позицию курсора после отмены или null. */
    fun undo(e: Editable): Int? {
        val ed = undoStack.removeLastOrNull() ?: return null
        apply(e, ed.start, ed.after.length, ed.before)
        redoStack.addLast(ed)
        breakMerge = true
        onChange?.invoke()
        return ed.start + ed.before.length
    }

    fun redo(e: Editable): Int? {
        val ed = redoStack.removeLastOrNull() ?: return null
        apply(e, ed.start, ed.before.length, ed.after)
        undoStack.addLast(ed)
        breakMerge = true
        onChange?.invoke()
        return ed.start + ed.after.length
    }

    private fun apply(e: Editable, start: Int, len: Int, text: String) {
        val s = start.coerceIn(0, e.length)
        val end = (s + len).coerceAtMost(e.length)
        enabled = false
        try {
            e.replace(s, end, text)
        } finally {
            enabled = true
        }
    }

    fun clear() {
        undoStack.clear()
        redoStack.clear()
        breakMerge = true
        onChange?.invoke()
    }

    private companion object {
        const val MERGE_MS = 1500L
        const val MAX_STEPS = 300
    }
}
