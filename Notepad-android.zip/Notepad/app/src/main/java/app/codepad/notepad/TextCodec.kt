package app.codepad.notepad

import java.io.IOException
import java.nio.ByteBuffer
import java.nio.CharBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction

class LoadedText(val text: String, val charset: Charset, val bom: Boolean, val lineEnding: String)

/** Чтение и запись текста: определение кодировки, BOM, окончаний строк. */
object TextCodec {
    private val BOM_UTF8 = byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte())
    private val BOM_UTF16LE = byteArrayOf(0xFF.toByte(), 0xFE.toByte())
    private val BOM_UTF16BE = byteArrayOf(0xFE.toByte(), 0xFF.toByte())

    val windows1251: Charset by lazy { Charset.forName("windows-1251") }

    fun decode(bytes: ByteArray, forced: Charset? = null): LoadedText {
        var charset: Charset
        var bom = false
        var offset = 0
        when {
            startsWith(bytes, BOM_UTF8) -> { charset = Charsets.UTF_8; bom = true; offset = 3 }
            startsWith(bytes, BOM_UTF16LE) -> { charset = Charsets.UTF_16LE; bom = true; offset = 2 }
            startsWith(bytes, BOM_UTF16BE) -> { charset = Charsets.UTF_16BE; bom = true; offset = 2 }
            else -> charset = Charsets.UTF_8
        }
        if (forced != null) {
            if (forced != charset) {
                offset = 0
                bom = false
            }
            charset = forced
        } else if (!bom) {
            if (looksBinary(bytes)) throw IOException("Похоже, это не текстовый файл.")
            charset = if (isValidUtf8(bytes)) Charsets.UTF_8 else windows1251
        }
        val raw = String(bytes, offset, bytes.size - offset, charset)
        val le = when {
            raw.contains("\r\n") -> "\r\n"
            raw.contains('\r') -> "\r"
            else -> "\n"
        }
        val text = if (le == "\n") raw else raw.replace("\r\n", "\n").replace('\r', '\n')
        return LoadedText(text, charset, bom, le)
    }

    /** Бросает CharacterCodingException, если символ нельзя записать в выбранной кодировке. */
    fun encode(text: String, charset: Charset, bom: Boolean, lineEnding: String): ByteArray {
        val s = if (lineEnding == "\n") text else text.replace("\n", lineEnding)
        val encoder = charset.newEncoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
        val buf = encoder.encode(CharBuffer.wrap(s))
        val body = ByteArray(buf.remaining()).also { buf.get(it) }
        if (!bom) return body
        val prefix = when (charset) {
            Charsets.UTF_8 -> BOM_UTF8
            Charsets.UTF_16LE -> BOM_UTF16LE
            Charsets.UTF_16BE -> BOM_UTF16BE
            else -> ByteArray(0)
        }
        return prefix + body
    }

    private fun startsWith(b: ByteArray, p: ByteArray): Boolean {
        if (b.size < p.size) return false
        for (i in p.indices) if (b[i] != p[i]) return false
        return true
    }

    private fun looksBinary(b: ByteArray): Boolean {
        val n = minOf(b.size, 8000)
        for (i in 0 until n) if (b[i].toInt() == 0) return true
        return false
    }

    private fun isValidUtf8(b: ByteArray): Boolean = try {
        Charsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
            .decode(ByteBuffer.wrap(b))
        true
    } catch (e: CharacterCodingException) {
        false
    }
}
