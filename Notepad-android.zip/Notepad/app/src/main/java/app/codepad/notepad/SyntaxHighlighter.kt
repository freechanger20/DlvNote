package app.codepad.notepad

import android.text.TextPaint
import android.text.style.CharacterStyle
import android.text.style.UpdateAppearance

enum class Tok { KEYWORD, TYPE, STRING, NUMBER, COMMENT, META, FUNCTION, TAG, ATTR }

class Token(val start: Int, val end: Int, val type: Tok)

/** Цвет подсветки. Не Parcelable — не попадает в буфер обмена при копировании. */
class HlSpan(private val color: Int) : CharacterStyle(), UpdateAppearance {
    override fun updateDrawState(tp: TextPaint) {
        tp.color = color
    }
}

/** Фон найденного совпадения. */
class FindSpan(private val color: Int) : CharacterStyle(), UpdateAppearance {
    override fun updateDrawState(tp: TextPaint) {
        tp.bgColor = color
    }
}

object HighlightColors {
    // порядок как в Tok
    private val light = intArrayOf(
        0xFFCF222E.toInt(), 0xFF953800.toInt(), 0xFF0A3069.toInt(), 0xFF0550AE.toInt(), 0xFF6E7781.toInt(),
        0xFF8250DF.toInt(), 0xFF6639BA.toInt(), 0xFF116329.toInt(), 0xFF0550AE.toInt(),
    )
    private val dark = intArrayOf(
        0xFFFF7B72.toInt(), 0xFFFFA657.toInt(), 0xFFA5D6FF.toInt(), 0xFF79C0FF.toInt(), 0xFF8B949E.toInt(),
        0xFFD2A8FF.toInt(), 0xFFD2A8FF.toInt(), 0xFF7EE787.toInt(), 0xFF79C0FF.toInt(),
    )

    fun palette(night: Boolean): IntArray = if (night) dark else light
}

/** Быстрый однопроходный лексер. Не идеальный парсер, но хорошо подходит для чтения кода. */
object SyntaxHighlighter {
    private const val MAX_TOKENS = 60_000

    fun tokenize(s: String, lang: Language): List<Token> = when (lang.kind) {
        Kind.CODE -> code(s, lang)
        Kind.MARKUP -> markup(s)
        Kind.MARKDOWN -> markdown(s)
        Kind.INI -> ini(s)
    }

    private fun isIdentStart(c: Char) = c.isLetter() || c == '_'
    private fun isIdentPart(c: Char, extra: String) = c.isLetterOrDigit() || c == '_' || extra.indexOf(c) >= 0

    private fun nextNonSpace(s: String, from: Int): Char {
        var j = from
        while (j < s.length && (s[j] == ' ' || s[j] == '\t')) j++
        return if (j < s.length) s[j] else '\u0000'
    }

    private fun atLineStart(s: String, i: Int): Boolean {
        var k = i - 1
        while (k >= 0 && (s[k] == ' ' || s[k] == '\t')) k--
        return k < 0 || s[k] == '\n'
    }

    private fun lineEnd(s: String, from: Int): Int = s.indexOf('\n', from).let { if (it < 0) s.length else it }

    private fun code(s: String, l: Language): List<Token> {
        val out = ArrayList<Token>()
        val n = s.length
        var i = 0
        outer@ while (i < n && out.size < MAX_TOKENS) {
            val c = s[i]
            if (c == ' ' || c == '\t' || c == '\n' || c == '\r') {
                i++
                continue
            }

            val bc = l.blockComment
            if (bc != null && s.startsWith(bc.first, i)) {
                val e = s.indexOf(bc.second, i + bc.first.length).let { if (it < 0) n else it + bc.second.length }
                out.add(Token(i, e, Tok.COMMENT))
                i = e
                continue
            }
            for (lc in l.lineComments) {
                if (s.startsWith(lc, i)) {
                    val e = lineEnd(s, i)
                    out.add(Token(i, e, Tok.COMMENT))
                    i = e
                    continue@outer
                }
            }

            if (l.preprocessor && c == '#' && atLineStart(s, i)) {
                var j = i + 1
                while (j < n && s[j] == ' ') j++
                while (j < n && s[j].isLetter()) j++
                out.add(Token(i, j, Tok.META))
                i = j
                continue
            }

            if (l.quotes.indexOf(c) >= 0) {
                if (l.tripleQuotes && i + 2 < n && s[i + 1] == c && s[i + 2] == c) {
                    val q = String(charArrayOf(c, c, c))
                    val e = s.indexOf(q, i + 3).let { if (it < 0) n else it + 3 }
                    out.add(Token(i, e, Tok.STRING))
                    i = e
                    continue
                }
                var j = i + 1
                while (j < n) {
                    val ch = s[j]
                    if (ch == '\\') {
                        j += 2
                        continue
                    }
                    if (ch == c) {
                        j++
                        break
                    }
                    if (ch == '\n' && c != '`') break
                    j++
                }
                if (j > n) j = n
                val type = if (l.keysBeforeColon && nextNonSpace(s, j) == ':') Tok.ATTR else Tok.STRING
                out.add(Token(i, j, type))
                i = j
                continue
            }

            if (l.varPrefix.indexOf(c) >= 0 && i + 1 < n && (isIdentPart(s[i + 1], "") || s[i + 1] == '{')) {
                var j = i + 1
                if (s[j] == '{') {
                    j = s.indexOf('}', j).let { if (it < 0) n else it + 1 }
                } else {
                    while (j < n && isIdentPart(s[j], l.extraIdent)) j++
                }
                out.add(Token(i, j, Tok.META))
                i = j
                continue
            }

            if (l.annotations && c == '@' && i + 1 < n && isIdentStart(s[i + 1])) {
                var j = i + 1
                while (j < n && (isIdentPart(s[j], l.extraIdent) || s[j] == '.')) j++
                out.add(Token(i, j, Tok.META))
                i = j
                continue
            }

            if (c.isDigit() && (i == 0 || !isIdentPart(s[i - 1], l.extraIdent))) {
                var j = i + 1
                while (j < n) {
                    val ch = s[j]
                    if (ch.isLetterOrDigit() || ch == '_') j++
                    else if (ch == '.' && j + 1 < n && s[j + 1].isDigit()) j++
                    else break
                }
                out.add(Token(i, j, Tok.NUMBER))
                i = j
                continue
            }

            if (isIdentStart(c)) {
                var j = i + 1
                while (j < n && isIdentPart(s[j], l.extraIdent)) j++
                val word = s.substring(i, j)
                val key = if (l.caseInsensitive) word.lowercase() else word
                val type = when {
                    key in l.keywords -> Tok.KEYWORD
                    l.keysBeforeColon && nextNonSpace(s, j) == ':' -> Tok.ATTR
                    key in l.types -> Tok.TYPE
                    l.capitalizedTypes && word[0].isUpperCase() && word.any { it.isLowerCase() } -> Tok.TYPE
                    j < n && s[j] == '(' -> Tok.FUNCTION
                    else -> null
                }
                if (type != null) out.add(Token(i, j, type))
                i = j
                continue
            }
            i++
        }
        return out
    }

    private fun markup(s: String): List<Token> {
        val out = ArrayList<Token>()
        val n = s.length
        var i = 0
        while (i < n && out.size < MAX_TOKENS) {
            val c = s[i]
            if (c == '<' && s.startsWith("<!--", i)) {
                val e = s.indexOf("-->", i + 4).let { if (it < 0) n else it + 3 }
                out.add(Token(i, e, Tok.COMMENT))
                i = e
                continue
            }
            if (c == '<' && s.startsWith("<![CDATA[", i)) {
                val e = s.indexOf("]]>", i + 9).let { if (it < 0) n else it + 3 }
                out.add(Token(i, e, Tok.STRING))
                i = e
                continue
            }
            if (c == '<' && i + 1 < n && (s[i + 1] == '/' || s[i + 1] == '!' || s[i + 1] == '?' || s[i + 1].isLetter())) {
                var j = i + 1
                if (s[j] == '/' || s[j] == '!' || s[j] == '?') j++
                while (j < n && (s[j].isLetterOrDigit() || s[j] == ':' || s[j] == '-' || s[j] == '_' || s[j] == '.')) j++
                out.add(Token(i, j, Tok.TAG))
                while (j < n && s[j] != '>' && s[j] != '<') {
                    val ch = s[j]
                    if (ch == '"' || ch == '\'') {
                        val e = s.indexOf(ch, j + 1).let { if (it < 0) n else it + 1 }
                        out.add(Token(j, e, Tok.STRING))
                        j = e
                    } else if (ch.isLetter() || ch == '_' || ch == ':' || ch == '@') {
                        val st = j
                        while (j < n && (s[j].isLetterOrDigit() || s[j] == '-' || s[j] == '_' || s[j] == ':' || s[j] == '.' || s[j] == '@')) j++
                        out.add(Token(st, j, Tok.ATTR))
                    } else if (ch == '/' || ch == '?') {
                        out.add(Token(j, j + 1, Tok.TAG))
                        j++
                    } else {
                        j++
                    }
                }
                if (j < n && s[j] == '>') {
                    out.add(Token(j, j + 1, Tok.TAG))
                    j++
                }
                i = j
                continue
            }
            if (c == '&') {
                var j = i + 1
                while (j < n && j - i < 12 && (s[j].isLetterOrDigit() || s[j] == '#')) j++
                if (j < n && s[j] == ';') {
                    out.add(Token(i, j + 1, Tok.NUMBER))
                    i = j + 1
                    continue
                }
            }
            i++
        }
        return out
    }

    private fun markdown(s: String): List<Token> {
        val out = ArrayList<Token>()
        val n = s.length
        var i = 0
        var fence = false
        while (i < n && out.size < MAX_TOKENS) {
            val e = lineEnd(s, i)
            var k = i
            while (k < e && (s[k] == ' ' || s[k] == '\t')) k++
            val isFence = s.startsWith("```", k) || s.startsWith("~~~", k)
            when {
                fence -> {
                    out.add(Token(i, e, Tok.STRING))
                    if (isFence) fence = false
                }
                isFence -> {
                    out.add(Token(i, e, Tok.STRING))
                    fence = true
                }
                k < e && s[k] == '#' -> out.add(Token(i, e, Tok.KEYWORD))
                k < e && s[k] == '>' -> out.add(Token(i, e, Tok.COMMENT))
                else -> {
                    if (k + 1 < e && (s[k] == '-' || s[k] == '*' || s[k] == '+') && s[k + 1] == ' ') {
                        out.add(Token(k, k + 1, Tok.TAG))
                    } else {
                        var d = k
                        while (d < e && s[d].isDigit()) d++
                        if (d > k && d + 1 < e && (s[d] == '.' || s[d] == ')') && s[d + 1] == ' ') out.add(Token(k, d + 1, Tok.TAG))
                    }
                    inlineMarkdown(s, k, e, out)
                }
            }
            i = e + 1
        }
        return out
    }

    private fun inlineMarkdown(s: String, from: Int, to: Int, out: MutableList<Token>) {
        var j = from
        while (j < to) {
            val c = s[j]
            if (c == '`') {
                val end = s.indexOf('`', j + 1)
                if (end in (j + 1) until to) {
                    out.add(Token(j, end + 1, Tok.STRING))
                    j = end + 1
                    continue
                }
            } else if (c == '[') {
                val close = s.indexOf(']', j + 1)
                if (close in (j + 1) until (to - 1) && s[close + 1] == '(') {
                    val pe = s.indexOf(')', close + 2)
                    if (pe in (close + 2) until to) {
                        out.add(Token(j, close + 1, Tok.FUNCTION))
                        out.add(Token(close + 1, pe + 1, Tok.ATTR))
                        j = pe + 1
                        continue
                    }
                }
            } else if ((c == '*' || c == '_') && j + 1 < to && s[j + 1] == c) {
                val end = s.indexOf(String(charArrayOf(c, c)), j + 2)
                if (end in (j + 2) until to) {
                    out.add(Token(j, end + 2, Tok.TYPE))
                    j = end + 2
                    continue
                }
            }
            j++
        }
    }

    private fun ini(s: String): List<Token> {
        val out = ArrayList<Token>()
        val n = s.length
        var i = 0
        while (i < n && out.size < MAX_TOKENS) {
            val e = lineEnd(s, i)
            var k = i
            while (k < e && (s[k] == ' ' || s[k] == '\t')) k++
            if (k < e) {
                val c = s[k]
                if (c == ';' || c == '#') {
                    out.add(Token(k, e, Tok.COMMENT))
                } else if (c == '[') {
                    out.add(Token(k, e, Tok.TAG))
                } else {
                    var eq = k
                    while (eq < e && s[eq] != '=' && s[eq] != ':') eq++
                    if (eq < e && eq > k) {
                        var keyEnd = eq
                        while (keyEnd > k && (s[keyEnd - 1] == ' ' || s[keyEnd - 1] == '\t')) keyEnd--
                        out.add(Token(k, keyEnd, Tok.ATTR))
                        var v = eq + 1
                        while (v < e && (s[v] == ' ' || s[v] == '\t')) v++
                        if (v < e) {
                            val value = s.substring(v, e).trim().lowercase()
                            val type = when {
                                s[v] == '"' || s[v] == '\'' -> Tok.STRING
                                value.toDoubleOrNull() != null -> Tok.NUMBER
                                value in setOf("true", "false", "yes", "no", "on", "off", "null") -> Tok.KEYWORD
                                else -> null
                            }
                            if (type != null) out.add(Token(v, e, type))
                        }
                    }
                }
            }
            i = e + 1
        }
        return out
    }
}
