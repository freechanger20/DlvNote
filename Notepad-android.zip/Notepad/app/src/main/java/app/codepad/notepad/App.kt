package app.codepad.notepad

import android.app.Application
import com.google.android.material.color.DynamicColors
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        // Цвета Material You из обоев (Android 12+)
        DynamicColors.applyToActivitiesIfAvailable(this)
    }
}

/** Фоновые потоки на всё время жизни процесса, чтобы сохранение не обрывалось при пересоздании экрана. */
object Workers {
    val io: ExecutorService = Executors.newSingleThreadExecutor()
    val highlight: ExecutorService = Executors.newSingleThreadExecutor()
}
