package app.codepad.notepad

import android.content.Context
import android.net.Uri
import androidx.appcompat.app.AppCompatDelegate
import org.json.JSONArray
import org.json.JSONObject

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var theme: Int
        get() = sp.getInt("theme", AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        set(v) = sp.edit().putInt("theme", v).apply()

    var fontSize: Float
        get() = sp.getFloat("font", 15f)
        set(v) = sp.edit().putFloat("font", v).apply()

    var wrap: Boolean
        get() = sp.getBoolean("wrap", true)
        set(v) = sp.edit().putBoolean("wrap", v).apply()

    var lineNumbers: Boolean
        get() = sp.getBoolean("ln", true)
        set(v) = sp.edit().putBoolean("ln", v).apply()

    var highlight: Boolean
        get() = sp.getBoolean("hl", true)
        set(v) = sp.edit().putBoolean("hl", v).apply()

    var suggestions: Boolean
        get() = sp.getBoolean("sugg", false)
        set(v) = sp.edit().putBoolean("sugg", v).apply()

    fun draftMeta(): String? = sp.getString("draft", null)
    fun saveDraftMeta(json: String) = sp.edit().putString("draft", json).apply()

    /** Список (uri, имя) недавних файлов, новые сверху. */
    fun recent(): List<Pair<String, String>> = runCatching {
        val a = JSONArray(sp.getString("recent", "[]"))
        (0 until a.length()).map { i -> a.getJSONObject(i).let { it.getString("u") to it.getString("n") } }
    }.getOrDefault(emptyList())

    fun addRecent(uri: Uri, name: String) {
        val u = uri.toString()
        val list = recent().filter { it.first != u }.toMutableList()
        list.add(0, u to name)
        writeRecent(list.take(15))
    }

    fun removeRecent(uri: Uri) {
        val u = uri.toString()
        writeRecent(recent().filter { it.first != u })
    }

    fun clearRecent() = writeRecent(emptyList())

    private fun writeRecent(list: List<Pair<String, String>>) {
        val a = JSONArray()
        list.forEach { (u, n) -> a.put(JSONObject().put("u", u).put("n", n)) }
        sp.edit().putString("recent", a.toString()).apply()
    }
}
