package app.codepad.notepad

enum class Kind { CODE, MARKUP, MARKDOWN, INI }

class Language(
    val id: String,
    val title: String,
    val extensions: List<String>,
    keywords: String = "",
    types: String = "",
    val lineComments: List<String> = emptyList(),
    val blockComment: Pair<String, String>? = null,
    val quotes: String = "\"'",
    val tripleQuotes: Boolean = false,
    val annotations: Boolean = false,
    val preprocessor: Boolean = false,
    val caseInsensitive: Boolean = false,
    val capitalizedTypes: Boolean = false,
    val keysBeforeColon: Boolean = false,
    val varPrefix: String = "",
    val extraIdent: String = "",
    val kind: Kind = Kind.CODE,
    val fileNames: List<String> = emptyList(),
) {
    val keywords: Set<String> = words(keywords)
    val types: Set<String> = words(types)

    private fun words(s: String): Set<String> =
        s.split(' ', '\n').filter { it.isNotEmpty() }.map { if (caseInsensitive) it.lowercase() else it }.toHashSet()
}

object Languages {
    private val C_COMMENTS = listOf("//")
    private val C_BLOCK = "/*" to "*/"

    val all: List<Language> = listOf(
        Language(
            "kotlin", "Kotlin", listOf("kt", "kts"),
            keywords = "package import class interface fun val var if else when for while do return break continue " +
                "object companion data sealed enum open abstract override private protected public internal inline " +
                "suspend try catch finally throw is in as typealias this super null true false init constructor by " +
                "where get set lateinit const operator infix vararg reified crossinline noinline annotation inner out " +
                "tailrec expect actual value it",
            types = "Int Long Short Byte Float Double Boolean Char String Unit Any Nothing",
            lineComments = C_COMMENTS, blockComment = C_BLOCK, tripleQuotes = true,
            annotations = true, capitalizedTypes = true,
        ),
        Language(
            "java", "Java / Groovy", listOf("java", "groovy", "gradle"),
            keywords = "abstract assert boolean break byte case catch char class const continue default do double else " +
                "enum extends final finally float for goto if implements import instanceof int interface long native " +
                "new package private protected public return short static strictfp super switch synchronized this " +
                "throw throws transient try void volatile while var record yield sealed permits true false null def",
            lineComments = C_COMMENTS, blockComment = C_BLOCK, tripleQuotes = true,
            annotations = true, capitalizedTypes = true,
        ),
        Language(
            "js", "JavaScript / TypeScript", listOf("js", "mjs", "cjs", "jsx", "ts", "tsx", "vue", "svelte"),
            keywords = "const let var function return if else for while do switch case default break continue new " +
                "delete typeof instanceof in of class extends super this null undefined true false try catch finally " +
                "throw async await yield import export from as static get set void interface type enum implements " +
                "private public protected readonly declare namespace abstract keyof debugger with satisfies",
            types = "any never unknown number string boolean object symbol bigint",
            lineComments = C_COMMENTS, blockComment = C_BLOCK, quotes = "\"'`",
            annotations = true, capitalizedTypes = true,
        ),
        Language(
            "python", "Python", listOf("py", "pyw", "pyi"),
            keywords = "and as assert async await break class continue def del elif else except False finally for " +
                "from global if import in is lambda None nonlocal not or pass raise return True try while with yield " +
                "match case self cls",
            types = "int float str bool list dict set tuple bytes object type range len print super isinstance",
            lineComments = listOf("#"), tripleQuotes = true, annotations = true, capitalizedTypes = true,
        ),
        Language(
            "c", "C / C++", listOf("c", "h", "cpp", "cc", "cxx", "hpp", "hh", "hxx", "ino", "m", "mm"),
            keywords = "auto break case char const continue default do double else enum extern float for goto if " +
                "inline int long register restrict return short signed sizeof static struct switch typedef union " +
                "unsigned void volatile while bool true false nullptr class namespace template typename public " +
                "private protected virtual override final new delete this using try catch throw operator friend " +
                "explicit constexpr noexcept static_cast dynamic_cast reinterpret_cast const_cast decltype mutable NULL",
            types = "size_t ssize_t uint8_t uint16_t uint32_t uint64_t int8_t int16_t int32_t int64_t string vector " +
                "map set std unique_ptr shared_ptr",
            lineComments = C_COMMENTS, blockComment = C_BLOCK, preprocessor = true,
        ),
        Language(
            "csharp", "C#", listOf("cs", "csx"),
            keywords = "abstract as base bool break byte case catch char checked class const continue decimal default " +
                "delegate do double else enum event explicit extern false finally fixed float for foreach goto if " +
                "implicit in int interface internal is lock long namespace new null object operator out override " +
                "params private protected public readonly ref return sbyte sealed short sizeof stackalloc static " +
                "string struct switch this throw true try typeof uint ulong unchecked unsafe ushort using virtual " +
                "void volatile while var async await get set value yield record init",
            lineComments = C_COMMENTS, blockComment = C_BLOCK, preprocessor = true, capitalizedTypes = true,
        ),
        Language(
            "go", "Go", listOf("go"),
            keywords = "break case chan const continue default defer else fallthrough for func go goto if import " +
                "interface map package range return select struct switch type var nil true false iota",
            types = "bool byte complex64 complex128 error float32 float64 int int8 int16 int32 int64 rune string " +
                "uint uint8 uint16 uint32 uint64 uintptr any",
            lineComments = C_COMMENTS, blockComment = C_BLOCK, quotes = "\"'`",
        ),
        Language(
            "rust", "Rust", listOf("rs"),
            keywords = "as async await break const continue crate dyn else enum extern false fn for if impl in let " +
                "loop match mod move mut pub ref return self Self static struct super trait true type unsafe use " +
                "where while",
            types = "i8 i16 i32 i64 i128 isize u8 u16 u32 u64 u128 usize f32 f64 bool char str",
            lineComments = C_COMMENTS, blockComment = C_BLOCK, quotes = "\"", capitalizedTypes = true,
        ),
        Language(
            "swift", "Swift", listOf("swift"),
            keywords = "associatedtype class deinit enum extension fileprivate func import init inout internal let " +
                "open operator private protocol public rethrows static struct subscript typealias var break case " +
                "continue default defer do else fallthrough for guard if in repeat return switch where while as catch " +
                "false is nil super self Self throw throws true try async await some any",
            lineComments = C_COMMENTS, blockComment = C_BLOCK, quotes = "\"", tripleQuotes = true,
            annotations = true, capitalizedTypes = true,
        ),
        Language(
            "dart", "Dart", listOf("dart"),
            keywords = "abstract as assert async await break case catch class const continue covariant default " +
                "deferred do dynamic else enum export extends extension external factory false final finally for " +
                "get hide if implements import in interface is late library mixin new null on operator part " +
                "required rethrow return set show static super switch sync this throw true try typedef var void " +
                "while with yield",
            types = "int double num bool String List Map Set Future Stream",
            lineComments = C_COMMENTS, blockComment = C_BLOCK, tripleQuotes = true,
            annotations = true, capitalizedTypes = true,
        ),
        Language(
            "php", "PHP", listOf("php", "phtml"),
            keywords = "abstract and array as break callable case catch class clone const continue declare default " +
                "do echo else elseif empty enddeclare endfor endforeach endif endswitch endwhile extends final " +
                "finally fn for foreach function global goto if implements include include_once instanceof " +
                "insteadof interface isset list match namespace new or print private protected public readonly " +
                "require require_once return static switch throw trait try unset use var while yield true false null",
            lineComments = listOf("//", "#"), blockComment = C_BLOCK, caseInsensitive = true, varPrefix = "$",
        ),
        Language(
            "ruby", "Ruby", listOf("rb", "rake", "gemspec"),
            keywords = "alias and begin break case class def defined do else elsif end ensure false for if in module " +
                "next nil not or redo rescue retry return self super then true undef unless until when while yield " +
                "require require_relative attr_accessor attr_reader attr_writer puts",
            lineComments = listOf("#"), annotations = true, capitalizedTypes = true, varPrefix = "$",
            fileNames = listOf("gemfile", "rakefile"),
        ),
        Language(
            "lua", "Lua", listOf("lua"),
            keywords = "and break do else elseif end false for function goto if in local nil not or repeat return " +
                "then true until while self",
            lineComments = listOf("--"), blockComment = "--[[" to "]]",
        ),
        Language(
            "shell", "Shell / Bash", listOf("sh", "bash", "zsh", "fish", "ksh", "command", "mk"),
            keywords = "if then else elif fi for while until do done case esac in function return exit break " +
                "continue local export readonly declare unset shift source alias echo cd set trap eval exec true " +
                "false sudo",
            lineComments = listOf("#"), quotes = "\"'`", varPrefix = "$",
            fileNames = listOf("makefile", "dockerfile", ".bashrc", ".zshrc", ".profile", ".bash_profile"),
        ),
        Language(
            "bat", "Batch / PowerShell", listOf("bat", "cmd", "ps1", "psm1"),
            keywords = "echo set if else goto call exit for in do not exist defined errorlevel pause rem cls " +
                "function param return foreach while switch try catch finally throw true false null",
            lineComments = listOf("::", "#", "REM ", "rem "), varPrefix = "$%", caseInsensitive = true,
        ),
        Language(
            "sql", "SQL", listOf("sql", "ddl", "dml"),
            keywords = "select from where and or not insert into values update set delete create table drop alter " +
                "add column index primary key foreign references join inner left right full outer cross on as " +
                "group by order asc desc having limit offset union all distinct case when then else end null is " +
                "in like between exists view trigger procedure function begin commit rollback transaction default " +
                "unique check constraint if returns return declare with recursive cascade",
            types = "int integer bigint smallint tinyint decimal numeric float real double char varchar text date " +
                "time timestamp datetime boolean bool blob serial uuid json jsonb",
            lineComments = listOf("--", "#"), blockComment = C_BLOCK, quotes = "'\"`", caseInsensitive = true,
        ),
        Language(
            "json", "JSON", listOf("json", "jsonc", "json5", "webmanifest", "geojson", "ipynb", "har"),
            keywords = "true false null",
            lineComments = C_COMMENTS, blockComment = C_BLOCK, quotes = "\"", keysBeforeColon = true,
        ),
        Language(
            "yaml", "YAML", listOf("yml", "yaml"),
            keywords = "true false null yes no on off True False Null",
            lineComments = listOf("#"), keysBeforeColon = true, extraIdent = "-.",
        ),
        Language(
            "css", "CSS / SCSS", listOf("css", "scss", "sass", "less"),
            keywords = "important inherit initial unset auto none",
            blockComment = C_BLOCK, keysBeforeColon = true, annotations = true, varPrefix = "$#",
            extraIdent = "-",
        ),
        Language("markup", "HTML / XML", listOf("html", "htm", "xhtml", "xml", "svg", "plist", "xsd", "xsl",
            "xslt", "xaml", "csproj", "fxml", "kml", "gpx", "rss", "atom"), kind = Kind.MARKUP),
        Language("markdown", "Markdown", listOf("md", "markdown", "mdx", "mkd"), kind = Kind.MARKDOWN),
        Language(
            "ini", "INI / Config", listOf("ini", "cfg", "conf", "properties", "toml", "env", "editorconfig",
                "gitconfig", "gitignore", "gitattributes", "service", "desktop", "reg", "inf"),
            kind = Kind.INI, fileNames = listOf(".env", ".gitignore", ".gitconfig", ".editorconfig"),
        ),
    )

    private val byExt: Map<String, Language> = buildMap {
        for (l in all) for (e in l.extensions) put(e, l)
    }

    fun byId(id: String): Language? = all.firstOrNull { it.id == id }

    fun detect(fileName: String): Language? {
        val lower = fileName.lowercase()
        all.firstOrNull { lower in it.fileNames }?.let { return it }
        val ext = lower.substringAfterLast('.', "")
        if (ext.isEmpty()) return null
        return byExt[ext]
    }
}
