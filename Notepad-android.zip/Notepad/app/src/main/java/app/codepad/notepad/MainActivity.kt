package app.codepad.notepad

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Typeface
import android.net.Uri
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.content.res.ColorStateList
import android.text.TextUtils
import android.view.Gravity
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.google.android.material.tabs.TabLayout
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.Settings
import android.os.Handler
import android.os.Looper
import android.print.PrintAttributes
import android.print.PrintManager
import android.provider.OpenableColumns
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.Spanned
import android.text.TextWatcher
import android.util.TypedValue
import android.view.ActionMode
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.webkit.MimeTypeMap
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContract
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.IntentCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.color.MaterialColors
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.progressindicator.LinearProgressIndicator
import java.io.File
import java.io.IOException
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import kotlin.math.max

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var toolbar: MaterialToolbar
    private lateinit var editor: CodeEditText
    private lateinit var progress: LinearProgressIndicator
    private lateinit var findBar: View
    private lateinit var replaceRow: View
    private lateinit var findInput: EditText
    private lateinit var replaceInput: EditText
    private lateinit var tabLayout: TabLayout

    private val main = Handler(Looper.getMainLooper())
    private val doc: Doc get() = Tabs.doc
    private val undo: UndoManager get() = doc.undo
    private var rebuildingTabs = false

    private var loading = false
    private var editCounter = 0
    private var hlGeneration = 0
    private var matchStart = -1
    private var matchEnd = -1
    private var menuRef: Menu? = null
    private var afterSave: (() -> Unit)? = null
    private var printView: WebView? = null

    private val readOnlyFilter = InputFilter { _, _, _, dest, dstart, dend -> dest.subSequence(dstart, dend) }
    private val hlRunnable = Runnable { runHighlight() }

    private val openLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            takePermission(uri)
            openUri(uri)
        }
    }

    private val createLauncher = registerForActivityResult(CreateDocumentContract()) { uri ->
        if (uri == null) {
            afterSave = null
        } else {
            takePermission(uri)
            doc.uri = uri
            queryName(uri)?.let { doc.name = it }
            writeTo(uri, fallbackToSaveAs = false)
        }
    }

    // ---------------------------------------------------------------- жизненный цикл

    override fun onCreate(savedInstanceState: Bundle?) {
        prefs = Prefs(this)
        AppCompatDelegate.setDefaultNightMode(prefs.theme)
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        toolbar = findViewById(R.id.toolbar)
        editor = findViewById(R.id.editor)
        progress = findViewById(R.id.progress)
        findBar = findViewById(R.id.find_bar)
        replaceRow = findViewById(R.id.replace_row)
        findInput = findViewById(R.id.find_input)
        replaceInput = findViewById(R.id.replace_input)
        tabLayout = findViewById(R.id.tabs)
        setSupportActionBar(toolbar)

        val root = findViewById<View>(R.id.root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            // панель продолжается под строку состояния, текст не уходит под клавиатуру
            v.setPadding(bars.left, 0, bars.right, max(bars.bottom, ime.bottom))
            val spacer = findViewById<View>(R.id.status_spacer)
            if (spacer.layoutParams.height != bars.top) {
                spacer.layoutParams = spacer.layoutParams.also { it.height = bars.top }
            }
            WindowInsetsCompat.CONSUMED
        }

        setupEditor()
        setupFindBar()
        setupTabs()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = onBack()
        })

        if (!Tabs.loaded) {
            Tabs.loaded = true
            restoreDraft()
        }
        rebuildTabs()
        showDocument(restoreSelection = true)
        if (savedInstanceState == null) handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onPause() {
        super.onPause()
        syncState()
        persistDraft()
    }

    override fun onDestroy() {
        main.removeCallbacks(hlRunnable)
        Tabs.docs.forEach { it.undo.onChange = null }
        super.onDestroy()
    }

    private fun syncState() {
        doc.text = editor.text?.toString() ?: ""
        doc.selStart = editor.selectionStart
        doc.selEnd = editor.selectionEnd
    }

    /** Сохраняет все вкладки во внутреннюю память, чтобы они открылись при следующем запуске. */
    private fun persistDraft() {
        if (::editor.isInitialized) syncState()
        val meta = Tabs.metaJson()
        val texts = Tabs.docs.map { it.id to it.text }
        val dir = File(filesDir, TABS_DIR)
        val p = prefs
        Workers.io.execute {
            runCatching {
                dir.mkdirs()
                val keep = HashSet<String>()
                for ((id, text) in texts) {
                    val f = File(dir, "$id.txt")
                    keep.add(f.name)
                    f.writeText(text)
                }
                dir.listFiles()?.forEach { if (it.name !in keep) it.delete() }
                p.saveTabsMeta(meta)
            }
        }
    }

    private fun restoreDraft() {
        val dir = File(filesDir, TABS_DIR)
        val meta = prefs.tabsMeta()
        if (meta != null) {
            runCatching {
                Tabs.applyMeta(meta) { id -> File(dir, "$id.txt").takeIf { it.exists() }?.readText() }
            }
            return
        }
        // перенос черновика из версии без вкладок
        val old = prefs.draftMeta() ?: return
        val file = File(filesDir, "draft.txt")
        if (!file.exists()) return
        runCatching {
            val d = Doc()
            d.applyJson(org.json.JSONObject(old))
            d.text = file.readText()
            Tabs.docs.clear()
            Tabs.docs.add(d)
            Tabs.current = 0
        }
    }

    private fun handleIntent(i: Intent?) {
        if (i == null) return
        when (i.action) {
            Intent.ACTION_VIEW, Intent.ACTION_EDIT -> {
                val uri = i.data ?: return
                takePermission(uri)
                openUri(uri)
            }
            Intent.ACTION_SEND -> {
                val stream = IntentCompat.getParcelableExtra(i, Intent.EXTRA_STREAM, Uri::class.java)
                val shared = i.getStringExtra(Intent.EXTRA_TEXT)
                when {
                    stream != null -> openUri(stream)
                    shared != null -> {
                        val d = Doc()
                        d.text = shared
                        d.dirty = true
                        addTab(d)
                    }
                }
            }
        }
    }

    // ---------------------------------------------------------------- редактор

    private fun setupEditor() {
        editor.isSaveEnabled = false
        editor.setTextSize(TypedValue.COMPLEX_UNIT_SP, prefs.fontSize)
        editor.showLineNumbers = prefs.lineNumbers
        applyInputType()

        editor.gutterTextColor = themeColor(com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFF888888.toInt())
        editor.gutterBgColor = themeColor(com.google.android.material.R.attr.colorSurfaceContainerLow, 0)
        editor.gutterLineColor = themeColor(com.google.android.material.R.attr.colorOutlineVariant, 0x22000000)

        // история правок своя у каждой вкладки
        editor.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) =
                undo.watcher.beforeTextChanged(s, start, count, after)
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) =
                undo.watcher.onTextChanged(s, start, before, count)
            override fun afterTextChanged(s: Editable?) = undo.watcher.afterTextChanged(s)
        })
        editor.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                editCounter++
                matchStart = -1
                if (loading) return
                doc.edits++
                if (!doc.dirty) {
                    doc.dirty = true
                    updateTitle()
                }
                scheduleHighlight(350)
            }
        })
        editor.onSelChanged = { _, _ -> updateSubtitle() }
        editor.onZoomEnd = { sp -> prefs.fontSize = sp }

        // в режиме чтения убираем «Вырезать» и «Вставить» из меню выделения
        val cb = object : ActionMode.Callback {
            override fun onCreateActionMode(mode: ActionMode?, menu: Menu?) = true
            override fun onPrepareActionMode(mode: ActionMode?, menu: Menu?): Boolean {
                if (doc.readOnly && menu != null) {
                    menu.removeItem(android.R.id.cut)
                    menu.removeItem(android.R.id.paste)
                    menu.removeItem(android.R.id.pasteAsPlainText)
                }
                return true
            }
            override fun onActionItemClicked(mode: ActionMode?, item: MenuItem?) = false
            override fun onDestroyActionMode(mode: ActionMode?) {}
        }
        editor.customSelectionActionModeCallback = cb
        editor.customInsertionActionModeCallback = cb
    }

    private fun themeColor(attr: Int, fallback: Int) = MaterialColors.getColor(editor, attr, fallback)

    private fun applyInputType() {
        var t = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        t = if (prefs.suggestions) {
            t or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES or InputType.TYPE_TEXT_FLAG_AUTO_CORRECT
        } else {
            t or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        }
        editor.inputType = t
        editor.typeface = Typeface.MONOSPACE
        editor.setHorizontallyScrolling(!prefs.wrap)
    }

    private fun showDocument(restoreSelection: Boolean) {
        Tabs.docs.forEach { it.undo.onChange = null }
        undo.onChange = { updateUndoItems() }
        loading = true
        undo.enabled = false
        withWritable { editor.setText(doc.text) }
        undo.enabled = true
        loading = false
        val len = editor.length()
        if (restoreSelection) {
            editor.setSelection(doc.selStart.coerceIn(0, len), doc.selEnd.coerceIn(0, len))
        } else {
            editor.setSelection(0)
            editor.scrollTo(0, 0)
        }
        applyReadOnly()
        scheduleHighlight(0)
        updateTitle()
        updateUndoItems()
    }

    private fun applyReadOnly() {
        val ro = doc.readOnly
        editor.filters = if (ro) arrayOf(readOnlyFilter) else emptyArray<InputFilter>()
        editor.showSoftInputOnFocus = !ro
        editor.isCursorVisible = !ro
        if (ro) hideKeyboard()
        replaceRow.visibility = if (ro) View.GONE else View.VISIBLE
        invalidateOptionsMenu()
        updateSubtitle()
    }

    /** Программная замена текста в обход фильтра «только чтение». */
    private inline fun withWritable(block: () -> Unit) {
        val saved = editor.filters
        editor.filters = emptyArray<InputFilter>()
        try {
            block()
        } finally {
            editor.filters = saved
        }
    }

    private fun toggleMode() {
        doc.readOnly = !doc.readOnly
        applyReadOnly()
        toast(if (doc.readOnly) "Режим чтения" else "Режим редактирования")
    }

    // ---------------------------------------------------------------- подсветка

    private fun currentLanguage(): Language? = when (val o = doc.langOverride) {
        null -> Languages.detect(doc.name)
        "" -> null
        else -> Languages.byId(o)
    }

    private fun isNightMode() =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    private fun scheduleHighlight(delay: Long) {
        main.removeCallbacks(hlRunnable)
        main.postDelayed(hlRunnable, delay)
    }

    private fun runHighlight() {
        val ed = editor.text ?: return
        val gen = ++hlGeneration
        val lang = currentLanguage()
        if (!prefs.highlight || lang == null || ed.length > MAX_HIGHLIGHT) {
            removeSpans(ed, HlSpan::class.java)
            return
        }
        val snapshot = ed.toString()
        val stamp = editCounter
        val palette = HighlightColors.palette(isNightMode())
        Workers.highlight.execute {
            val tokens = try {
                SyntaxHighlighter.tokenize(snapshot, lang)
            } catch (t: Throwable) {
                emptyList()
            }
            main.post {
                if (isDestroyed || gen != hlGeneration || stamp != editCounter) return@post
                val e = editor.text ?: return@post
                removeSpans(e, HlSpan::class.java)
                val len = e.length
                for (t in tokens) {
                    if (t.end > len) break
                    if (t.end > t.start) e.setSpan(HlSpan(palette[t.type.ordinal]), t.start, t.end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
            }
        }
    }

    private fun <T> removeSpans(e: Editable, cls: Class<T>) {
        for (sp in e.getSpans(0, e.length, cls)) e.removeSpan(sp)
    }

    // ---------------------------------------------------------------- заголовок и меню

    private fun charsetLabel(): String {
        val cs = doc.charset
        return when {
            cs == Charsets.UTF_8 && doc.bom -> "UTF-8 BOM"
            cs == Charsets.UTF_8 -> "UTF-8"
            cs == Charsets.UTF_16LE -> "UTF-16 LE"
            cs == Charsets.UTF_16BE -> "UTF-16 BE"
            else -> cs.displayName()
        }
    }

    private fun updateTitle() {
        supportActionBar?.title = (if (doc.dirty) "• " else "") + doc.name
        refreshTabLabels()
        updateSubtitle()
    }

    private fun updateSubtitle() {
        if (!::editor.isInitialized) return
        val pos = editor.selectionStart.coerceAtLeast(0)
        val line = editor.lineOf(pos)
        val col = pos - editor.lineStartOffset(line)
        val lang = currentLanguage()?.title ?: "Текст"
        val mode = if (doc.readOnly) " · чтение" else ""
        supportActionBar?.subtitle = "${line + 1}:${col + 1} · ${charsetLabel()} · $lang$mode"
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main, menu)
        menuRef = menu
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        val ro = doc.readOnly
        menu.findItem(R.id.action_mode)?.apply {
            setIcon(if (ro) R.drawable.ic_edit else R.drawable.ic_read)
            title = if (ro) "Редактировать" else "Режим чтения"
        }
        menu.findItem(R.id.action_wrap)?.isChecked = prefs.wrap
        menu.findItem(R.id.action_line_numbers)?.isChecked = prefs.lineNumbers
        menu.findItem(R.id.action_highlight)?.isChecked = prefs.highlight
        menu.findItem(R.id.action_suggestions)?.isChecked = prefs.suggestions
        updateUndoItems(menu)
        return super.onPrepareOptionsMenu(menu)
    }

    private fun updateUndoItems(menu: Menu? = menuRef) {
        if (menu == null) return
        val ro = doc.readOnly
        for ((id, enabled) in listOf(R.id.action_undo to undo.canUndo, R.id.action_redo to undo.canRedo)) {
            val item = menu.findItem(id) ?: continue
            item.isVisible = !ro
            item.isEnabled = enabled
            item.icon?.mutate()?.alpha = if (enabled) 255 else 80
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_mode -> toggleMode()
            R.id.action_undo -> doUndo()
            R.id.action_redo -> doRedo()
            R.id.action_save -> save()
            R.id.action_new -> newDocument()
            R.id.action_open -> launchOpen()
            R.id.action_close_tab -> closeTab(Tabs.current)
            R.id.action_recent -> showRecent()
            R.id.action_save_as -> saveAs()
            R.id.action_find -> showFind()
            R.id.action_goto -> showGoto()
            R.id.action_print -> printDocument()
            R.id.action_share -> share()
            R.id.action_encoding -> showEncodingDialog()
            R.id.action_language -> showLanguageDialog()
            R.id.action_wrap -> {
                prefs.wrap = !prefs.wrap
                editor.setHorizontallyScrolling(!prefs.wrap)
                if (prefs.wrap) editor.scrollTo(0, editor.scrollY)
                invalidateOptionsMenu()
            }
            R.id.action_line_numbers -> {
                prefs.lineNumbers = !prefs.lineNumbers
                editor.showLineNumbers = prefs.lineNumbers
                invalidateOptionsMenu()
            }
            R.id.action_highlight -> {
                prefs.highlight = !prefs.highlight
                scheduleHighlight(0)
                invalidateOptionsMenu()
            }
            R.id.action_suggestions -> {
                prefs.suggestions = !prefs.suggestions
                applyInputType()
                invalidateOptionsMenu()
            }
            R.id.action_font -> showFontDialog()
            R.id.action_theme -> showThemeDialog()
            R.id.action_about -> showAbout()
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    private fun doUndo() {
        if (doc.readOnly) return
        val e = editor.text ?: return
        val pos = undo.undo(e) ?: return
        editor.setSelection(pos.coerceIn(0, editor.length()))
    }

    private fun doRedo() {
        if (doc.readOnly) return
        val e = editor.text ?: return
        val pos = undo.redo(e) ?: return
        editor.setSelection(pos.coerceIn(0, editor.length()))
    }

    // ---------------------------------------------------------------- файлы

    private fun newDocument() = addTab(Doc())

    private fun launchOpen() {
        try {
            openLauncher.launch(arrayOf("*/*"))
        } catch (e: ActivityNotFoundException) {
            showError("Не найдено приложение для выбора файлов.")
        }
    }

    /**
     * Открывает файл. Уже открытый файл просто выбирается; иначе — новая вкладка
     * (или текущая, если она пустая). С [forced] — перечитать текущую вкладку в другой кодировке.
     */
    private fun openUri(uri: Uri, forced: Charset? = null, forcedBom: Boolean = false, knownName: String? = null) {
        if (forced == null) {
            val existing = Tabs.indexOfUri(uri)
            if (existing >= 0) {
                switchTo(existing)
                return
            }
        }
        setBusy(true)
        val resolver = contentResolver
        Workers.io.execute {
            val name = queryName(uri) ?: knownName
            val result = runCatching {
                val size = querySize(uri)
                if (size != null && size > MAX_FILE) throw IOException(tooBig(size))
                val bytes = try {
                    resolver.openInputStream(uri)?.use { it.readBytes() }
                        ?: throw IOException("Не удалось открыть файл.")
                } catch (e: Exception) {
                    // разрешение от «Моих файлов» истекло — читаем напрямую, если есть доступ ко всем файлам
                    val f = if (hasAllFilesAccess()) resolveFile(uri, name) else null
                    if (f == null || f.length() > MAX_FILE) throw e
                    f.readBytes()
                }
                if (bytes.size > MAX_FILE) throw IOException(tooBig(bytes.size.toLong()))
                TextCodec.decode(bytes, forced)
            }
            main.post {
                if (isDestroyed) return@post
                setBusy(false)
                result.onSuccess { f ->
                    val d = if (forced != null) doc else Doc()
                    if (forced != null) d.undo.clear()
                    d.text = f.text
                    d.uri = uri
                    d.name = name ?: "файл.txt"
                    d.charset = f.charset
                    d.bom = if (forced != null) forcedBom else f.bom
                    d.lineEnding = f.lineEnding
                    d.dirty = false
                    d.selStart = 0
                    d.selEnd = 0
                    if (forced != null) {
                        showDocument(restoreSelection = false)
                    } else {
                        syncState()
                        if (doc.isBlank) {
                            Tabs.docs[Tabs.current] = d
                            rebuildTabs()
                            showDocument(restoreSelection = false)
                        } else {
                            addTab(d)
                        }
                    }
                    prefs.addRecent(uri, d.name)
                    persistDraft()
                }.onFailure { e ->
                    if (e is SecurityException) prefs.removeRecent(uri)
                    showError(
                        when (e) {
                            is SecurityException -> "Нет доступа к файлу. Откройте его заново через «Открыть…»."
                            is OutOfMemoryError -> "Файл слишком большой."
                            else -> e.message ?: "Не удалось открыть файл."
                        }
                    )
                }
            }
        }
    }

    private fun tooBig(size: Long) = "Файл слишком большой (${size / 1024 / 1024} МБ). Максимум — ${MAX_FILE / 1024 / 1024} МБ."

    private fun save(then: (() -> Unit)? = null) {
        afterSave = then
        val uri = doc.uri
        if (uri == null) launchCreate() else writeTo(uri, fallbackToSaveAs = true)
    }

    private fun saveAs(then: (() -> Unit)? = null) {
        afterSave = then
        launchCreate()
    }

    private fun launchCreate() {
        val name = doc.name
        val ext = name.substringAfterLast('.', "").lowercase()
        // для неизвестных расширений (.kt, .py…) — octet-stream, иначе система допишет .txt
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
        try {
            createLauncher.launch(name to mime)
        } catch (e: ActivityNotFoundException) {
            afterSave = null
            showError("Не найдено приложение для сохранения файлов.")
        }
    }

    private fun writeTo(uri: Uri, fallbackToSaveAs: Boolean) {
        val d = doc
        val text = editor.text?.toString() ?: ""
        val cs = d.charset
        val bom = d.bom
        val le = d.lineEnding
        val stamp = d.edits
        val resolver = contentResolver
        setBusy(true)
        val name = doc.name
        Workers.io.execute {
            val result = runCatching {
                val bytes = TextCodec.encode(text, cs, bom, le)
                try {
                    val out = try {
                        resolver.openOutputStream(uri, "wt")
                    } catch (e: Exception) {
                        null
                    } ?: resolver.openOutputStream(uri, "w") ?: throw IOException("Не удалось открыть файл для записи.")
                    out.use { it.write(bytes) }
                } catch (e: Exception) {
                    // файл открыт «только для чтения» — пишем в него напрямую
                    val f = if (hasAllFilesAccess()) resolveFile(uri, name) else null
                    if (f == null) throw e
                    f.writeBytes(bytes)
                }
            }
            main.post {
                if (isDestroyed) return@post
                setBusy(false)
                result.onSuccess {
                    if (stamp == d.edits) d.dirty = false
                    updateTitle()
                    scheduleHighlight(0)
                    prefs.addRecent(uri, d.name)
                    persistDraft()
                    toast("Сохранено: ${d.name}")
                    val cb = afterSave
                    afterSave = null
                    cb?.invoke()
                }.onFailure { e ->
                    when {
                        e is CharacterCodingException -> {
                            afterSave = null
                            showError("В тексте есть символы, которые нельзя записать в кодировке ${charsetLabel()}. Выберите UTF-8 в меню «Кодировка».")
                        }
                        fallbackToSaveAs -> showNoWriteDialog()
                        else -> {
                            afterSave = null
                            showError("Не удалось сохранить: ${e.message}")
                        }
                    }
                }
            }
        }
    }

    // ---------------------------------------------------------------- доступ ко всем файлам

    private fun hasAllFilesAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        }

    private val allFilesLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        onAllFilesResult()
    }

    private val legacyPermLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        onAllFilesResult()
    }

    private fun onAllFilesResult() {
        if (hasAllFilesAccess()) {
            toast("Доступ получен")
            val uri = doc.uri
            if (uri != null) writeTo(uri, fallbackToSaveAs = true) else afterSave = null
        } else {
            afterSave = null
            toast("Доступ не выдан")
        }
    }

    private fun showNoWriteDialog() {
        if (hasAllFilesAccess()) {
            // доступ есть, но путь к файлу не удалось определить
            MaterialAlertDialogBuilder(this)
                .setTitle("Не удалось записать файл")
                .setMessage("Откройте файл через ⋮ → «Открыть…» — тогда он будет сохраняться на месте. Или сохраните копию.")
                .setPositiveButton("Сохранить как…") { _, _ -> launchCreate() }
                .setNegativeButton("Отмена") { _, _ -> afterSave = null }
                .show()
            return
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Нет прав на запись")
            .setMessage(
                "Приложение, из которого открыт файл, разрешило Блокноту только чтение.\n\n" +
                    "Чтобы сохранять изменения прямо в этот же файл, разрешите Блокноту доступ ко всем файлам. " +
                    "Это нужно сделать один раз: на следующем экране включите переключатель и вернитесь назад."
            )
            .setPositiveButton("Разрешить") { _, _ -> requestAllFiles() }
            .setNeutralButton("Сохранить как…") { _, _ -> launchCreate() }
            .setNegativeButton("Отмена") { _, _ -> afterSave = null }
            .show()
    }

    private fun requestAllFiles() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val perApp = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
            try {
                allFilesLauncher.launch(perApp)
            } catch (e: ActivityNotFoundException) {
                try {
                    allFilesLauncher.launch(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                } catch (e2: ActivityNotFoundException) {
                    afterSave = null
                    showError("Откройте Настройки → Приложения → Блокнот → Разрешения и разрешите доступ к файлам.")
                }
            }
        } else {
            legacyPermLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
    }

    /** Настоящий файл в памяти телефона, на который указывает content-ссылка, или null. */
    private fun resolveFile(uri: Uri, name: String?): File? {
        if (uri.scheme == "file") return uri.path?.let { File(it) }?.takeIf { it.isFile }
        val root = Environment.getExternalStorageDirectory().path
        val candidates = LinkedHashSet<String>()

        runCatching {
            contentResolver.query(uri, arrayOf("_data"), null, null, null)?.use { c ->
                val i = c.getColumnIndex("_data")
                if (c.moveToFirst() && i >= 0 && !c.isNull(i)) candidates.add(c.getString(i))
            }
        }
        runCatching {
            if (DocumentsContract.isDocumentUri(this, uri)) {
                val id = DocumentsContract.getDocumentId(uri)
                when {
                    id.startsWith("raw:") -> candidates.add(id.removePrefix("raw:"))
                    id.startsWith("primary:") -> candidates.add(root + "/" + id.removePrefix("primary:"))
                    id.contains(':') -> {
                        val vol = id.substringBefore(':')
                        if (vol.isNotEmpty() && !vol.all { it.isDigit() }) candidates.add("/storage/$vol/" + id.substringAfter(':'))
                    }
                }
            }
        }
        val path = uri.path ?: ""
        val storageIdx = path.indexOf("/storage/")
        if (storageIdx >= 0) candidates.add(path.substring(storageIdx))
        val sdcardIdx = path.indexOf("/sdcard/")
        if (sdcardIdx >= 0) candidates.add(root + path.substring(sdcardIdx + 7))
        // например content://…myfiles…/device_storage/0/Download/file.txt → /storage/emulated/0/Download/file.txt
        val segs = uri.pathSegments
        for (i in segs.indices) candidates.add(root + "/" + segs.subList(i, segs.size).joinToString("/"))

        return candidates.asSequence()
            .map { File(it) }
            .firstOrNull { f -> runCatching { f.isFile && (name == null || f.name == name) }.getOrDefault(false) }
    }

    private fun takePermission(uri: Uri) {
        val rw = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        try {
            contentResolver.takePersistableUriPermission(uri, rw)
        } catch (e: Exception) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
            }
        }
    }

    private fun queryName(uri: Uri): String? = runCatching {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst() && !c.isNull(0)) c.getString(0) else null
        }
    }.getOrNull() ?: uri.lastPathSegment?.substringAfterLast('/')

    private fun querySize(uri: Uri): Long? = runCatching {
        contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
            if (c.moveToFirst() && !c.isNull(0)) c.getLong(0) else null
        }
    }.getOrNull()

    private fun onBack() {
        if (findBar.visibility == View.VISIBLE) {
            hideFind()
            return
        }
        val dirty = Tabs.docs.count { it.dirty }
        if (dirty == 0) {
            finish()
            return
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Есть несохранённые вкладки: $dirty")
            .setMessage("Они останутся открытыми при следующем запуске, но в файлы изменения не записаны.")
            .setPositiveButton("Выйти") { _, _ -> finish() }
            .setNegativeButton("Отмена", null)
            .show()
    }

    // ---------------------------------------------------------------- вкладки

    private fun setupTabs() {
        tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                if (!rebuildingTabs) switchTo(tab.position)
            }
            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })
        findViewById<View>(R.id.tab_add).setOnClickListener { newDocument() }
    }

    private fun tabLabel(d: Doc) = (if (d.dirty) "• " else "") + d.name

    private val tabTextColors: ColorStateList by lazy {
        ColorStateList(
            arrayOf(intArrayOf(android.R.attr.state_selected), intArrayOf()),
            intArrayOf(
                themeColor(com.google.android.material.R.attr.colorPrimary, 0xFF3949AB.toInt()),
                themeColor(com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFF666666.toInt()),
            )
        )
    }

    private fun makeTabView(d: Doc): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            id = android.R.id.text1
            text = tabLabel(d)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.MIDDLE
            maxWidth = dp(170)
            textSize = 14f
            setTextColor(tabTextColors)
        }
        val close = ImageView(this).apply {
            setImageResource(R.drawable.ic_close)
            imageTintList = tabTextColors
            contentDescription = "Закрыть вкладку"
            setPadding(dp(5), dp(5), dp(5), dp(5))
            val tv = TypedValue()
            theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true)
            setBackgroundResource(tv.resourceId)
            setOnClickListener {
                val i = Tabs.docs.indexOf(d)
                if (i >= 0) closeTab(i)
            }
        }
        row.addView(title)
        row.addView(close, LinearLayout.LayoutParams(dp(28), dp(28)).apply { marginStart = dp(4) })
        return row
    }

    private fun rebuildTabs() {
        rebuildingTabs = true
        tabLayout.removeAllTabs()
        Tabs.docs.forEachIndexed { i, d ->
            val tab = tabLayout.newTab().setText(tabLabel(d)).setCustomView(makeTabView(d))
            tabLayout.addTab(tab, i == Tabs.current)
        }
        rebuildingTabs = false
        val cur = Tabs.current
        tabLayout.post { tabLayout.setScrollPosition(cur, 0f, true) }
    }

    private fun refreshTabLabels() {
        if (!::tabLayout.isInitialized) return
        Tabs.docs.forEachIndexed { i, d ->
            val tab = tabLayout.getTabAt(i) ?: return@forEachIndexed
            val label = tabLabel(d)
            if (tab.text?.toString() != label) {
                tab.text = label
                tab.customView?.findViewById<TextView>(android.R.id.text1)?.text = label
            }
        }
    }

    private fun selectTabUi(i: Int) {
        val tab = tabLayout.getTabAt(i) ?: return
        if (!tab.isSelected) {
            rebuildingTabs = true
            tab.select()
            rebuildingTabs = false
        }
    }

    private fun switchTo(i: Int) {
        if (i !in Tabs.docs.indices) return
        if (i != Tabs.current) {
            syncState()
            Tabs.current = i
            editor.text?.let { removeSpans(it, FindSpan::class.java) }
            matchStart = -1
            showDocument(restoreSelection = true)
        }
        selectTabUi(i)
    }

    private fun addTab(d: Doc) {
        syncState()
        val pos = (Tabs.current + 1).coerceAtMost(Tabs.docs.size)
        Tabs.docs.add(pos, d)
        Tabs.current = pos
        rebuildTabs()
        showDocument(restoreSelection = false)
        persistDraft()
    }

    private fun closeTab(i: Int) {
        if (i !in Tabs.docs.indices) return
        val d = Tabs.docs[i]
        if (i != Tabs.current) switchTo(i)
        if (!d.dirty) {
            removeTab(d)
            return
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Сохранить изменения?")
            .setMessage("В «${d.name}» есть несохранённые изменения.")
            .setPositiveButton("Сохранить") { _, _ -> save { removeTab(d) } }
            .setNegativeButton("Не сохранять") { _, _ -> removeTab(d) }
            .setNeutralButton("Отмена", null)
            .show()
    }

    private fun removeTab(d: Doc) {
        val i = Tabs.docs.indexOf(d)
        if (i < 0) return
        syncState()
        Tabs.docs.removeAt(i)
        if (Tabs.docs.isEmpty()) Tabs.docs.add(Doc())
        if (i < Tabs.current) Tabs.current--
        Tabs.current = Tabs.current.coerceIn(0, Tabs.docs.size - 1)
        d.undo.onChange = null
        rebuildTabs()
        showDocument(restoreSelection = true)
        persistDraft()
    }

    private fun showRecent() {
        val list = prefs.recent()
        if (list.isEmpty()) {
            toast("Недавних файлов нет")
            return
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Недавние файлы")
            .setItems(list.map { it.second }.toTypedArray()) { _, i ->
                val uri = Uri.parse(list[i].first)
                openUri(uri, knownName = list[i].second)
            }
            .setNeutralButton("Очистить") { _, _ -> prefs.clearRecent() }
            .setNegativeButton("Закрыть", null)
            .show()
    }

    private fun share() {
        val uri = doc.uri
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, doc.name)
            if (uri != null && !doc.dirty) {
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } else {
                putExtra(Intent.EXTRA_TEXT, (editor.text?.toString() ?: "").take(500_000))
            }
        }
        try {
            startActivity(Intent.createChooser(send, "Поделиться"))
        } catch (e: ActivityNotFoundException) {
            showError("Нет приложений, чтобы поделиться.")
        }
    }

    // ---------------------------------------------------------------- печать

    private fun printDocument() {
        val pm = getSystemService(Context.PRINT_SERVICE) as? PrintManager
        if (pm == null) {
            showError("Печать на этом устройстве недоступна.")
            return
        }
        val text = editor.text?.toString() ?: ""
        val lang = if (prefs.highlight) currentLanguage() else null
        val html = HtmlExport.build(doc.name, text, lang, prefs.lineNumbers)
        setBusy(true)
        val wv = WebView(this)
        var started = false
        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                if (started || view == null || isDestroyed) return
                started = true
                setBusy(false)
                val job = doc.name
                pm.print(
                    job,
                    view.createPrintDocumentAdapter(job),
                    PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build()
                )
            }
        }
        wv.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
        printView = wv
    }

    // ---------------------------------------------------------------- поиск и замена

    private fun setupFindBar() {
        findInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                findNext(true)
                true
            } else false
        }
        findViewById<View>(R.id.find_prev).setOnClickListener { findNext(false) }
        findViewById<View>(R.id.find_next).setOnClickListener { findNext(true) }
        findViewById<View>(R.id.find_close).setOnClickListener { hideFind() }
        findViewById<View>(R.id.replace_one).setOnClickListener { replaceOne() }
        findViewById<View>(R.id.replace_all).setOnClickListener { replaceAll() }
    }

    private fun showFind() {
        findBar.visibility = View.VISIBLE
        val s = editor.selectionStart
        val e = editor.selectionEnd
        if (s in 0 until e && e - s < 200) {
            val sel = editor.text?.subSequence(s, e)?.toString() ?: ""
            if (!sel.contains('\n')) findInput.setText(sel)
        }
        findInput.requestFocus()
        findInput.selectAll()
        WindowCompat.getInsetsController(window, findInput).show(WindowInsetsCompat.Type.ime())
    }

    private fun hideFind() {
        findBar.visibility = View.GONE
        editor.text?.let { removeSpans(it, FindSpan::class.java) }
        matchStart = -1
        hideKeyboard()
    }

    private fun findNext(forward: Boolean) {
        val q = findInput.text.toString()
        if (q.isEmpty()) return
        val text = editor.text?.toString() ?: return
        val from = when {
            matchStart >= 0 -> if (forward) matchEnd else matchStart
            forward -> editor.selectionEnd
            else -> editor.selectionStart
        }.coerceIn(0, text.length)
        var idx = if (forward) text.indexOf(q, from, ignoreCase = true)
        else if (from > 0) text.lastIndexOf(q, from - 1, ignoreCase = true) else -1
        if (idx < 0) {
            idx = if (forward) text.indexOf(q, 0, ignoreCase = true) else text.lastIndexOf(q, ignoreCase = true)
            if (idx >= 0) toast(if (forward) "Поиск с начала" else "Поиск с конца")
        }
        if (idx < 0) {
            toast("Не найдено")
            return
        }
        markMatch(idx, idx + q.length)
    }

    private fun markMatch(s: Int, e: Int) {
        val ed = editor.text ?: return
        removeSpans(ed, FindSpan::class.java)
        val color = themeColor(com.google.android.material.R.attr.colorPrimary, 0xFF3949AB.toInt())
        ed.setSpan(FindSpan((color and 0x00FFFFFF) or 0x66000000), s, e, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        editor.setSelection(s, e)
        editor.bringPointIntoView(e)
        editor.bringPointIntoView(s)
        matchStart = s
        matchEnd = e
    }

    private fun replaceOne() {
        if (doc.readOnly) {
            toast("Включите режим редактирования")
            return
        }
        val q = findInput.text.toString()
        if (q.isEmpty()) return
        val ed = editor.text ?: return
        val s = matchStart
        val e = matchEnd
        if (s >= 0 && e <= ed.length && ed.subSequence(s, e).toString().equals(q, ignoreCase = true)) {
            val r = replaceInput.text.toString()
            ed.replace(s, e, r)
            editor.setSelection(s + r.length)
        }
        findNext(true)
    }

    private fun replaceAll() {
        if (doc.readOnly) {
            toast("Включите режим редактирования")
            return
        }
        val q = findInput.text.toString()
        if (q.isEmpty()) return
        val ed = editor.text ?: return
        val r = replaceInput.text.toString()
        var count = 0
        val result = Regex(Regex.escape(q), RegexOption.IGNORE_CASE).replace(ed.toString()) {
            count++
            r
        }
        if (count == 0) {
            toast("Не найдено")
        } else {
            ed.replace(0, ed.length, result)
            toast("Заменено: $count")
        }
    }

    // ---------------------------------------------------------------- диалоги

    private fun showGoto() {
        val total = editor.lineCountLogical()
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = "1 – $total"
        }
        val box = FrameLayout(this).apply {
            setPadding(dp(24), dp(8), dp(24), 0)
            addView(input)
        }
        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle("Перейти к строке")
            .setView(box)
            .setPositiveButton("Перейти") { _, _ ->
                val n = input.text.toString().toIntOrNull() ?: return@setPositiveButton
                val off = editor.lineStartOffset((n - 1).coerceIn(0, total - 1))
                editor.requestFocus()
                editor.setSelection(off)
                editor.bringPointIntoView(off)
            }
            .setNegativeButton("Отмена", null)
            .create()
        dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        dialog.show()
        input.requestFocus()
    }

    private val encodings: List<Triple<String, Charset, Boolean>> by lazy {
        listOf(
            Triple("UTF-8", "UTF-8", false),
            Triple("UTF-8 с BOM", "UTF-8", true),
            Triple("UTF-16 LE", "UTF-16LE", true),
            Triple("UTF-16 BE", "UTF-16BE", true),
            Triple("Windows-1251 (кириллица)", "windows-1251", false),
            Triple("KOI8-U", "KOI8-U", false),
            Triple("KOI8-R", "KOI8-R", false),
            Triple("CP866 (DOS)", "IBM866", false),
            Triple("ISO-8859-1 (латиница)", "ISO-8859-1", false),
        ).mapNotNull { (label, name, bom) ->
            runCatching { Triple(label, Charset.forName(name), bom) }.getOrNull()
        }
    }

    private fun showEncodingDialog() {
        val current = encodings.indexOfFirst { it.second == doc.charset && it.third == doc.bom }
        MaterialAlertDialogBuilder(this)
            .setTitle("Кодировка")
            .setSingleChoiceItems(encodings.map { it.first }.toTypedArray(), current) { d, which ->
                d.dismiss()
                val (label, cs, bom) = encodings[which]
                val uri = doc.uri
                if (uri != null && !doc.dirty) {
                    openUri(uri, cs, bom)
                    toast("Файл перечитан в $label")
                } else {
                    doc.charset = cs
                    doc.bom = bom
                    updateSubtitle()
                    toast("Файл будет сохранён в $label")
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun showLanguageDialog() {
        val detected = Languages.detect(doc.name)?.title ?: "обычный текст"
        val labels = mutableListOf("Автоматически ($detected)", "Обычный текст")
        labels.addAll(Languages.all.map { it.title })
        val current = when (val o = doc.langOverride) {
            null -> 0
            "" -> 1
            else -> Languages.all.indexOfFirst { it.id == o } + 2
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Язык подсветки")
            .setSingleChoiceItems(labels.toTypedArray(), current) { d, which ->
                d.dismiss()
                doc.langOverride = when (which) {
                    0 -> null
                    1 -> ""
                    else -> Languages.all[which - 2].id
                }
                if (!prefs.highlight && which != 1) {
                    prefs.highlight = true
                    invalidateOptionsMenu()
                }
                scheduleHighlight(0)
                updateSubtitle()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun showFontDialog() {
        val sizes = intArrayOf(10, 12, 13, 14, 15, 16, 18, 20, 22, 24, 28, 32)
        val cur = prefs.fontSize
        val checked = sizes.indices.minByOrNull { kotlin.math.abs(sizes[it] - cur) } ?: 4
        MaterialAlertDialogBuilder(this)
            .setTitle("Размер шрифта")
            .setSingleChoiceItems(sizes.map { "$it sp" }.toTypedArray(), checked) { d, which ->
                d.dismiss()
                prefs.fontSize = sizes[which].toFloat()
                editor.setTextSize(TypedValue.COMPLEX_UNIT_SP, prefs.fontSize)
            }
            .setNegativeButton("Отмена", null)
            .show()
        toast("Масштаб можно менять и двумя пальцами")
    }

    private fun showThemeDialog() {
        val modes = intArrayOf(
            AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM,
            AppCompatDelegate.MODE_NIGHT_NO,
            AppCompatDelegate.MODE_NIGHT_YES,
        )
        val labels = arrayOf("Как в системе", "Светлая", "Тёмная")
        MaterialAlertDialogBuilder(this)
            .setTitle("Тема")
            .setSingleChoiceItems(labels, modes.indexOf(prefs.theme).coerceAtLeast(0)) { d, which ->
                d.dismiss()
                prefs.theme = modes[which]
                AppCompatDelegate.setDefaultNightMode(modes[which])
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun showAbout() {
        MaterialAlertDialogBuilder(this)
            .setTitle("${getString(R.string.app_name)} ${BuildConfig.VERSION_NAME}")
            .setMessage(
                "Редактор текста и кода.\n\n" +
                    "• Открытие и сохранение любых текстовых файлов\n" +
                    "• Режим чтения без случайных правок\n" +
                    "• Подсветка ${Languages.all.size} языков\n" +
                    "• Печать и сохранение в PDF\n" +
                    "• Кодировки UTF-8, Windows-1251, KOI8 и др.\n" +
                    "• Масштаб текста двумя пальцами"
            )
            .setPositiveButton("OK", null)
            .show()
    }

    // ---------------------------------------------------------------- мелочи

    private fun setBusy(busy: Boolean) {
        progress.visibility = if (busy) View.VISIBLE else View.GONE
    }

    private fun hideKeyboard() {
        WindowCompat.getInsetsController(window, editor).hide(WindowInsetsCompat.Type.ime())
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun showError(msg: String) {
        MaterialAlertDialogBuilder(this).setMessage(msg).setPositiveButton("OK", null).show()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    companion object {
        private const val TABS_DIR = "tabs"
        private const val MAX_FILE = 10L * 1024 * 1024
        private const val MAX_HIGHLIGHT = 300_000
    }
}

/** «Сохранить как» с нужным MIME-типом, чтобы система не меняла расширение файла. */
class CreateDocumentContract : ActivityResultContract<Pair<String, String>, Uri?>() {
    override fun createIntent(context: Context, input: Pair<String, String>): Intent =
        Intent(Intent.ACTION_CREATE_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType(input.second)
            .putExtra(Intent.EXTRA_TITLE, input.first)

    override fun parseResult(resultCode: Int, intent: Intent?): Uri? =
        if (resultCode == Activity.RESULT_OK) intent?.data else null
}
