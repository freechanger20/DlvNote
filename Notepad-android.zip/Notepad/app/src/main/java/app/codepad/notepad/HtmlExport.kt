package app.codepad.notepad

/** HTML для печати: моноширинный текст, номера строк и подсветка в светлой схеме. */
object HtmlExport {
    fun build(title: String, text: String, lang: Language?, lineNumbers: Boolean): String {
        val types = ByteArray(text.length).also { it.fill(-1) }
        if (lang != null) {
            for (t in SyntaxHighlighter.tokenize(text, lang)) {
                val end = minOf(t.end, text.length)
                for (k in t.start until end) types[k] = t.type.ordinal.toByte()
            }
        }
        val palette = HighlightColors.palette(false)
        val lines = text.split('\n')
        val digits = lines.size.toString().length

        val sb = StringBuilder(text.length * 2 + 2048)
        sb.append("<!DOCTYPE html><html><head><meta charset=\"utf-8\"><title>")
            .append(escape(title))
            .append("</title><style>")
            .append("@page{margin:12mm}")
            .append("body{margin:0;font-family:monospace;font-size:9.5pt;color:#1F2328;tab-size:4}")
            .append("h1{font-family:sans-serif;font-size:11pt;font-weight:600;margin:0 0 8pt;padding-bottom:4pt;border-bottom:1px solid #D0D7DE}")
            .append(".l{display:flex;line-height:1.4}")
            .append(".n{flex:0 0 auto;min-width:").append(digits).append("ch;text-align:right;padding-right:1em;color:#8C959F}")
            .append(".c{flex:1 1 auto;white-space:pre-wrap;overflow-wrap:anywhere;word-break:break-all}")
            .append("</style></head><body><h1>").append(escape(title)).append("</h1>")

        var offset = 0
        lines.forEachIndexed { idx, line ->
            sb.append("<div class=\"l\">")
            if (lineNumbers) sb.append("<span class=\"n\">").append(idx + 1).append("</span>")
            sb.append("<span class=\"c\">")
            if (line.isEmpty()) sb.append(' ')
            var k = 0
            while (k < line.length) {
                val ty = types[offset + k].toInt()
                var e = k + 1
                while (e < line.length && types[offset + e].toInt() == ty) e++
                val chunk = escape(line.substring(k, e))
                if (ty < 0) {
                    sb.append(chunk)
                } else {
                    sb.append("<span style=\"color:").append(hex(palette[ty])).append("\">").append(chunk).append("</span>")
                }
                k = e
            }
            sb.append("</span></div>")
            offset += line.length + 1
        }
        sb.append("</body></html>")
        return sb.toString()
    }

    private fun hex(c: Int) = String.format("#%06X", c and 0xFFFFFF)

    private fun escape(s: String): String {
        val sb = StringBuilder(s.length + 16)
        for (ch in s) {
            when (ch) {
                '&' -> sb.append("&amp;")
                '<' -> sb.append("&lt;")
                '>' -> sb.append("&gt;")
                '"' -> sb.append("&quot;")
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }
}
