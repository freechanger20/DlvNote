package app.codepad.notepad

import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.nio.charset.Charset
import java.util.UUID

/** Один открытый документ (вкладка). */
class Doc(val id: String = UUID.randomUUID().toString().take(12)) {
    var text: String = ""
    var uri: Uri? = null
    var name: String = DEFAULT_NAME
    var charset: Charset = Charsets.UTF_8
    var bom = false
    var lineEnding = "\n"
    var dirty = false
    var readOnly = false
    /** null — определять по расширению, "" — обычный текст, иначе id языка. */
    var langOverride: String? = null
    var selStart = 0
    var selEnd = 0
    /** Счётчик правок: чтобы после сохранения не снять «•», если текст успели изменить. */
    var edits = 0

    val undo = UndoManager()

    /** Пустая безымянная вкладка, которую можно занять открываемым файлом. */
    val isBlank: Boolean get() = uri == null && !dirty && text.isEmpty()

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("uri", uri?.toString() ?: "")
        put("name", name)
        put("cs", charset.name())
        put("bom", bom)
        put("le", lineEnding)
        put("dirty", dirty)
        put("ro", readOnly)
        put("lang", langOverride ?: JSONObject.NULL)
        put("ss", selStart)
        put("se", selEnd)
    }

    fun applyJson(j: JSONObject) {
        uri = j.optString("uri").takeIf { it.isNotEmpty() }?.let { Uri.parse(it) }
        name = j.optString("name", DEFAULT_NAME)
        charset = runCatching { Charset.forName(j.optString("cs", "UTF-8")) }.getOrDefault(Charsets.UTF_8)
        bom = j.optBoolean("bom")
        lineEnding = j.optString("le", "\n")
        dirty = j.optBoolean("dirty")
        readOnly = j.optBoolean("ro")
        langOverride = if (j.has("lang") && !j.isNull("lang")) j.getString("lang") else null
        selStart = j.optInt("ss")
        selEnd = j.optInt("se")
    }

    companion object {
        const val DEFAULT_NAME = "Без имени.txt"

        fun fromJson(j: JSONObject): Doc {
            val id = j.optString("id").ifEmpty { UUID.randomUUID().toString().take(12) }
            return Doc(id).also { it.applyJson(j) }
        }
    }
}

/** Открытые вкладки. Живут дольше активности: переживают смену темы и поворот экрана. */
object Tabs {
    var loaded = false
    val docs = mutableListOf(Doc())
    var current = 0

    val doc: Doc get() = docs[current.coerceIn(0, docs.size - 1)]

    fun indexOfUri(uri: Uri): Int = docs.indexOfFirst { it.uri == uri }

    fun metaJson(): String = JSONObject().apply {
        put("cur", current)
        put("docs", JSONArray().apply { docs.forEach { put(it.toJson()) } })
    }.toString()

    /** Восстанавливает список вкладок; тексты подставляет [loadText]. */
    fun applyMeta(json: String, loadText: (String) -> String?) {
        val j = JSONObject(json)
        val arr = j.getJSONArray("docs")
        val list = mutableListOf<Doc>()
        for (i in 0 until arr.length()) {
            val d = Doc.fromJson(arr.getJSONObject(i))
            d.text = loadText(d.id) ?: continue
            list.add(d)
        }
        if (list.isEmpty()) return
        docs.clear()
        docs.addAll(list)
        current = j.optInt("cur").coerceIn(0, docs.size - 1)
    }
}
