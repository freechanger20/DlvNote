package app.codepad.notepad

import android.net.Uri
import org.json.JSONObject
import java.nio.charset.Charset

/** Текущий документ. Живёт дольше активности: переживает смену темы и поворот экрана. */
object DocState {
    const val DEFAULT_NAME = "Без имени.txt"

    var loaded = false
    var text: String = ""
    var uri: Uri? = null
    var name: String = DEFAULT_NAME
    var charset: Charset = Charsets.UTF_8
    var bom = false
    var lineEnding = "\n"
    var dirty = false
    var readOnly = false
    /** null — определять по расширению, "" — обычный текст, иначе id языка. */
    var langOverride: String? = null
    var selStart = 0
    var selEnd = 0

    val undo = UndoManager()

    fun reset() {
        text = ""
        uri = null
        name = DEFAULT_NAME
        charset = Charsets.UTF_8
        bom = false
        lineEnding = "\n"
        dirty = false
        readOnly = false
        langOverride = null
        selStart = 0
        selEnd = 0
        undo.clear()
    }

    fun metaJson(): String = JSONObject().apply {
        put("uri", uri?.toString() ?: "")
        put("name", name)
        put("cs", charset.name())
        put("bom", bom)
        put("le", lineEnding)
        put("dirty", dirty)
        put("ro", readOnly)
        put("lang", langOverride)
        put("ss", selStart)
        put("se", selEnd)
    }.toString()

    fun applyMeta(json: String) {
        val j = JSONObject(json)
        uri = j.optString("uri").takeIf { it.isNotEmpty() }?.let { Uri.parse(it) }
        name = j.optString("name", DEFAULT_NAME)
        charset = runCatching { Charset.forName(j.optString("cs", "UTF-8")) }.getOrDefault(Charsets.UTF_8)
        bom = j.optBoolean("bom")
        lineEnding = j.optString("le", "\n")
        dirty = j.optBoolean("dirty")
        readOnly = j.optBoolean("ro")
        langOverride = if (j.has("lang")) j.getString("lang") else null
        selStart = j.optInt("ss")
        selEnd = j.optInt("se")
    }
}
