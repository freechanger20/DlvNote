package app.codepad.notepad

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.util.AttributeSet
import android.util.TypedValue
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import androidx.appcompat.widget.AppCompatEditText

/**
 * Поле редактора: номера строк слева, масштаб щипком, вставка без форматирования.
 */
class CodeEditText(context: Context, attrs: AttributeSet?) : AppCompatEditText(context, attrs) {

    var onSelChanged: ((Int, Int) -> Unit)? = null
    var onZoomEnd: ((Float) -> Unit)? = null

    var showLineNumbers = true
        set(v) {
            field = v
            if (ready) updateGutter()
        }
    var gutterTextColor = Color.GRAY
        set(v) {
            field = v
            if (ready) { numPaint.color = v; invalidate() }
        }
    var gutterBgColor = Color.TRANSPARENT
        set(v) {
            field = v
            if (ready) { bgPaint.color = v; invalidate() }
        }
    var gutterLineColor = Color.TRANSPARENT
        set(v) {
            field = v
            if (ready) { linePaint.color = v; invalidate() }
        }

    private val numPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.RIGHT
        typeface = Typeface.MONOSPACE
    }
    private val bgPaint = Paint()
    private val linePaint = Paint().apply { strokeWidth = resources.displayMetrics.density }
    private val basePad = (8 * resources.displayMetrics.density).toInt()
    private var gutterWidth = 0
    private var lastDigits = 0

    // позиции символов '\n' для быстрого «номер строки по смещению»
    private var nl = IntArray(64)
    private var nlCount = 0
    private var nlDirty = true

    private var gutterCheckPosted = false
    private val gutterCheck = Runnable {
        gutterCheckPosted = false
        val d = digitsFor(lineCountLogical())
        if (d != lastDigits) updateGutter()
    }

    private var multiTouch = false
    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            val sd = scaledDensity()
            val px = (textSize * detector.scaleFactor).coerceIn(8 * sd, 40 * sd)
            setTextSize(TypedValue.COMPLEX_UNIT_PX, px)
            return true
        }

        override fun onScaleEnd(detector: ScaleGestureDetector) {
            onZoomEnd?.invoke(textSize / scaledDensity())
        }
    })

    private var ready = false

    init {
        numPaint.color = gutterTextColor
        ready = true
        updateGutter()
    }

    @Suppress("DEPRECATION")
    private fun scaledDensity() = resources.displayMetrics.scaledDensity

    private fun digitsFor(lines: Int) = maxOf(2, lines.toString().length)

    fun updateGutter() {
        if (!ready) return
        numPaint.textSize = textSize * 0.8f
        lastDigits = digitsFor(lineCountLogical())
        gutterWidth = if (showLineNumbers) {
            (numPaint.measureText("0".repeat(lastDigits)) + basePad * 2).toInt()
        } else 0
        val left = gutterWidth + basePad
        if (paddingLeft != left) setPadding(left, paddingTop, paddingRight, paddingBottom)
        invalidate()
    }

    private fun ensureNl() {
        if (!nlDirty) return
        val t = text
        var arr = nl
        var c = 0
        if (t != null) {
            val n = t.length
            for (i in 0 until n) {
                if (t[i] == '\n') {
                    if (c == arr.size) arr = arr.copyOf(arr.size * 2)
                    arr[c++] = i
                }
            }
        }
        nl = arr
        nlCount = c
        nlDirty = false
    }

    /** Номер логической строки (с нуля) для смещения в тексте. */
    fun lineOf(offset: Int): Int {
        ensureNl()
        var lo = 0
        var hi = nlCount
        while (lo < hi) {
            val m = (lo + hi) ushr 1
            if (nl[m] < offset) lo = m + 1 else hi = m
        }
        return lo
    }

    fun lineStartOffset(line: Int): Int {
        ensureNl()
        return when {
            line <= 0 -> 0
            line - 1 < nlCount -> nl[line - 1] + 1
            else -> text?.length ?: 0
        }
    }

    fun lineCountLogical(): Int {
        ensureNl()
        return nlCount + 1
    }

    override fun onTextChanged(text: CharSequence?, start: Int, lengthBefore: Int, lengthAfter: Int) {
        super.onTextChanged(text, start, lengthBefore, lengthAfter)
        if (!ready) return
        nlDirty = true
        if (!gutterCheckPosted) {
            gutterCheckPosted = true
            post(gutterCheck)
        }
    }

    override fun onSelectionChanged(selStart: Int, selEnd: Int) {
        super.onSelectionChanged(selStart, selEnd)
        if (ready) onSelChanged?.invoke(selStart, selEnd)
    }

    override fun setTextSize(unit: Int, size: Float) {
        super.setTextSize(unit, size)
        if (ready) updateGutter()
    }

    override fun onDraw(canvas: Canvas) {
        val lay = layout
        if (showLineNumbers && gutterWidth > 0 && lay != null) {
            val sx = scrollX.toFloat()
            val top = scrollY
            val bottom = scrollY + height
            val gw = gutterWidth.toFloat()
            canvas.drawRect(sx, top.toFloat(), sx + gw, bottom.toFloat(), bgPaint)
            canvas.drawLine(sx + gw, top.toFloat(), sx + gw, bottom.toFloat(), linePaint)
            val padTop = totalPaddingTop
            val first = lay.getLineForVertical(maxOf(0, top - padTop))
            val last = lay.getLineForVertical(maxOf(0, bottom - padTop))
            val t = text
            val x = sx + gw - basePad
            for (i in first..last) {
                val st = lay.getLineStart(i)
                if (i == 0 || (t != null && st > 0 && st <= t.length && t[st - 1] == '\n')) {
                    val y = (lay.getLineBaseline(i) + padTop).toFloat()
                    canvas.drawText((lineOf(st) + 1).toString(), x, y, numPaint)
                }
            }
        }
        super.onDraw(canvas)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.actionMasked == MotionEvent.ACTION_DOWN) multiTouch = false
        scaleDetector.onTouchEvent(event)
        if (event.pointerCount > 1) {
            if (!multiTouch) {
                multiTouch = true
                val cancel = MotionEvent.obtain(event)
                cancel.action = MotionEvent.ACTION_CANCEL
                super.onTouchEvent(cancel)
                cancel.recycle()
            }
            return true
        }
        if (multiTouch) {
            if (event.actionMasked == MotionEvent.ACTION_UP || event.actionMasked == MotionEvent.ACTION_CANCEL) multiTouch = false
            return true
        }
        return super.onTouchEvent(event)
    }

    /** Вставка всегда без чужого форматирования. */
    override fun onTextContextMenuItem(id: Int): Boolean =
        super.onTextContextMenuItem(if (id == android.R.id.paste) android.R.id.pasteAsPlainText else id)
}
